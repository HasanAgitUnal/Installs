# PROPRIETARY AND CONFIDENTIAL SOFTWARE
# Copyright (c) 2025 Hasan Agit Ünal. All rights reserved.
#
# This software and its source code are strictly confidential, proprietary,
# and owned exclusively by Hasan Agit Ünal.
#
# STRICTLY PROHIBITED:
# - Any unauthorized use, reproduction, distribution, or modification
# - Reverse engineering, decompiling, or disassembling
# - Commercial or non-commercial use of any kind
# - Inclusion in other projects without written permission
# - Any sharing, demonstration, or distribution
#
# Violations will be pursued to the fullest extent of the law.


import logging
import os
import time
import json
import re
import datetime
import cbor2 # type: ignore

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("/var/log/pi-server/logs.log"),
        logging.StreamHandler()
    ]
)

PLUGIN_FOLDER = "/etc/pi-server/plugin"
SENSOR_FOLDER = PLUGIN_FOLDER + "/data/sensor"
DATA_HISTORY = 924

def update_classes(class_name):
        with open(PLUGIN_FOLDER + "/data/classes.json", "r+", encoding="utf-8") as f:
            classesl = json.load(f)
            if class_name not in classesl:
                logging.info("Yeni sınıf bulundu liste güncelleniyor")
                f.seek(0)
                f.truncate()
                classesl.append(class_name.replace("_", "/"))
                json.dump(classesl, f)

def main_loop(client):
    while True:
        now = datetime.datetime.now()
        if now.hour in range(7, 19):
            client.publish("commands/update", "-", 1, False)
            logging.info("Sensörler güncelleniyor")
            # wait 5 min (300)
            time.sleep(300)

            # clear log file if too large
            with open("/var/log/pi-server/logs.log") as f:
                if len(f.readlines()) > 1000:
                    os.system("pi-server --clear-logs")

        else:
            # skip idle time
            if now.hour >= 18:
                sleep_seconds = ((24 - now.hour + 7) * 3600) - now.minute*60 - now.second
            else:
                sleep_seconds = ((7 - now.hour) * 3600) - now.minute*60 - now.second
            time.sleep(sleep_seconds)

def on_message(client, userdata, message):
    payload = message.payload.decode()
    logging.info(f"Gelen mesaj: topic: {message.topic}, mesaj : {payload}")

    if message.topic == "app_get":
        if payload == "sensor_data":
            logging.info(f"Sensör verisi istendi: '{payload}'")
            class_data = {}

            # Output format: {"class_name": [["file", "file_content"]]}
            for dirpath, dirnames, filenames in os.walk(SENSOR_FOLDER):

                if dirpath == SENSOR_FOLDER:
                    continue

                class_name = os.path.basename(dirpath).replace("_", "/")
                logging.debug(f"'{class_name}' sınıfı için sensör verileri işleniyor...")
                class_data[class_name] = []

                for filename in filenames:
                    sensor_name = os.path.splitext(filename)[0] # Remove file extension
                    full_path = os.path.join(dirpath, filename)
                    # Add file content
                    with open(full_path, 'r', encoding='utf-8') as f:
                        file_content = f.read().splitlines()
                    class_data[class_name].append([sensor_name, file_content])

            client.publish("get/sensor_data", cbor2.dumps(class_data), 1, False)

            logging.info(f"Sensör verileri gönderildi")

        elif payload == "remote_control":
        # output: { "class name": [{ "text": "example", "topic": "commands/example" }, ...], ... }
            with open(PLUGIN_FOLDER+"/data/remote_control.json", "r") as f:
                remote_control_data = json.load(f)

            cbor_remote = cbor2.dumps(remote_control_data)
            client.publish("get/remote_control", cbor_remote, 1, False)
            logging.info("Kumanda bilgileri gönderildi: " + payload)

        elif payload == "alerts":
            # output: [ {"text": "example", "topic": "sensors/alert/example"}, {"textFromTopic": true, "topic": "sensors/example2"},  ... ]
            with open(PLUGIN_FOLDER+"/data/alerts.json", "r", encoding="utf-8") as f:
                alerts_data = json.load(f)

            cbor_alerts_data = cbor2.dumps(alerts_data)
            client.publish("get/alerts", cbor_alerts_data, 1, False)
            logging.info("Bildirim bilgileri gönderildi")

        elif payload == "classes":
            # output: [ "1/A", "1/B", ... ]
            with open(PLUGIN_FOLDER+"/data/classes.json", "r", encoding="utf-8") as f:
                classes_data = json.load(f)

            cbor_classes_data = cbor2.dumps(classes_data)
            client.publish("get/classes", cbor_classes_data, 1, False)
            logging.info("Sınıf listesi gönderildi")

    elif message.topic == "sensors/update":
        # Sensör veri örnek formatı:
        # {
        #   "class": "1/A", // yada 1_A
        #   "type": "ısı",
        #   "value": "20°C"
        # }

        try:
            sensor_data = json.loads(payload)
        except json.JSONDecodeError:
            logging.warning("HATA: Geçersiz json:\n\t"+payload)

        for k in ["class", "type", "value"]:
            if not k in sensor_data.keys():
                logging.warning("HATA: Geçersiz sensör verisi:\n\t"+json.dumps(sensor_data, indent=4, ensure_ascii=False))
                return

        s_class = sensor_data["class"].replace("/", "_")
        s_type = sensor_data["type"]
        s_value = sensor_data["value"]

        update_classes(s_class)

        # Split value and unit
        match = re.search(r'([-+]?\d*\.?\d+)\s*(.*)', s_value)
        if match:
            num_value = match.group(1)
            unit = match.group(2).strip()
        else:
            logging.warning("HATA: Okunan sensör verisi geçersiz: \n\t"+json.dumps(sensor_data, indent=4, ensure_ascii=False))
            return

        date = datetime.datetime.now()
        fdate = date.strftime("%d-%m-%Y-%H-%M")
        full_value = fdate + "-" + num_value + "-" + unit + "\n"

        # file to write sensor data
        data_folder = os.path.join(PLUGIN_FOLDER, "data", "sensor", s_class)
        data_file = os.path.join(PLUGIN_FOLDER, "data", "sensor", s_class, s_type + ".txt")

        os.makedirs(data_folder, exist_ok=True)

        try:
             # Get lines
            with open(data_file, 'r') as f:
                lines = f.readlines()
        except FileNotFoundError:
            lines = []

        lines.append(full_value)

        # Update file
        with open(data_file, 'w', encoding='utf-8') as f:
            f.writelines(lines[-DATA_HISTORY:])

        logging.info(f"Sensör verisi güncellendi: Sensör: {s_class}_{s_type}. Veri: {s_value}")
    elif message.topic == "sensors/add_control":
        # message format:
        # {
        #   "text": "Trigger Bulbs",
        #   "topic": "commands/bulbs",
        #   "class": "1/A",
        # }

        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            logging.error("Geçersiz kumanda JSON formatı: " + payload)

        if 'class' in data.keys() and 'text' in data.keys() and 'topic' in data.keys():
            class_name = data["class"]
        else:
            logging.error("Geçersiz kumanda verisi: " + payload)
            return

        update_classes(data["class"])

	# delete class name from data
        button = data
        del button["class"]

        with open(PLUGIN_FOLDER+"/data/remote_control.json", "r") as f:
            file_data = json.load(f)

            # if sensor button already defined exit
            if class_name in file_data.keys() and  button in file_data[class_name]:
                return
            elif not class_name in file_data.keys():
                file_data[class_name] = [] # init if not initialized

        # add button to file
        with open(PLUGIN_FOLDER+"/data/remote_control.json", "w") as f:
            file_data[class_name].append(button)
            json.dump(file_data, f, ensure_ascii=False)

        logging.info("Kumanda bilgisi güncellendi:" + class_name)

    elif message.topic == "sensors/add_alert":
        # message format:
        # {
        #   "text": "OKUL YANIYOR!!!!", // can remove this if getTextFromTopic is used
        #   "topic": "sensors/alert/okul_yanıyor" // if a message from this topic sended app will send a notification
        #   "textFromTopic": false // this is optional. app will load message from payload.
        # }

        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            logging.error("Geçersiz bildirim formatı: JSON değil: " + payload)
            return

        if not "topic" in data.keys():
            logging.error("Geçersi bildirim formatı: Bildirim \"topic\" değerini içermiyor : "+payload)
            return

        elif not "text" in data.keys() and not "textFromTopic" in data.keys():
            logging.error("Geçersiz bildirim formatı: Bildirim \"text\" yada \"textFromTopic\" içermiyor : "+payload)
            return

        # Remove "text" if "textFromTopic" is used
        if "textFromTopic" in data.keys() and data["textFromTopic"] == True:
            try:
                del data["text"]
            except KeyError:
                pass

        # Open file for updating
        with open(PLUGIN_FOLDER+"/data/alerts.json", "r", encoding="utf-8") as f:
            alerts = json.load(f)

        # Return if already exists
        if data in alerts:
            return

        # Update and write
        with open(PLUGIN_FOLDER+"/data/alerts.json", "w", encoding="utf-8") as f:
            alerts.append(data)
            json.dump(data, f, ensure_ascii=False)

        logging.info("Yeni bildirim eklendi")
